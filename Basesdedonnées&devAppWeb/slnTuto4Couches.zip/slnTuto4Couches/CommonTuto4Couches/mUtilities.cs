﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonTuto4Couches
{
    public class mUtilities
    {
        public static SqlConnection maDBConnection()
        {
            //définition de la chaine de connexion
            string conxstr = @"Data Source=(local)\SQLEXPRESS;Initial Catalog=dbTuto4Couches;Integrated Security=True";
            SqlConnection conX = new SqlConnection(conxstr);
            return conX;
        }

    }
}
