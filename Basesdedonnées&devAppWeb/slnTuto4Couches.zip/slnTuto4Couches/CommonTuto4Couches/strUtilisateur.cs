﻿namespace CommonTuto4Couches
{
    public struct strUtilisateur
    {
        public string UserLogin;
        public string UserMotPass;
        public string UserNomComplet;
        public string UserRole;
        public string UserEmail;
    }

}