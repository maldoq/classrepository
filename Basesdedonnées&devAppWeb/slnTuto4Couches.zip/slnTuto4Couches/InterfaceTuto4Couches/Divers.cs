﻿using MetierTuto4Couches;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceTuto4Couches
{
    public class Divers
    {
        public static Boolean ExisteUtilisateur(string pCode)
        {
            Utilisateur unUser = new Utilisateur(pCode);
            if (unUser.UserLogin == null)
            {
                return false;
            }
            else
            {
                if (unUser.UserLogin.ToUpper() == pCode.ToUpper())
                {
                    return true;
                }
                return false;
            }
        }
    }

}
