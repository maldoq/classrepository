﻿using MetierTuto4Couches;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfaceTuto4Couches
{
    public partial class FrmUtilisateurListe : Form
    {
        public FrmUtilisateurListe()
        {
            InitializeComponent();
            rafraichirList();
        }

        private void rafraichirList()
        {
            lviewRech.Items.Clear();
            DataTable dt = Utilisateur.SelectAll(txtFiltre.Text);
            foreach (DataRow row in dt.Rows)
            {
                string vLogin = "";
                string vNomPrenom = "";
                string vEmail = "";
                string vRole = "";

                if (!DBNull.Value.Equals(row["UserLogin"])) vLogin = (string)row["UserLogin"];
                if (!DBNull.Value.Equals(row["UserNomComplet"])) vNomPrenom = (string)row["UserNomComplet"];
                if (!DBNull.Value.Equals(row["UserRole"])) vRole = (string)row["UserRole"];
                if (!DBNull.Value.Equals(row["UserEmail"])) vEmail = (string)row["UserEmail"];

                ListViewItem itm = lviewRech.Items.Add(vLogin);
                itm.SubItems.Add(vNomPrenom);
                itm.SubItems.Add(vRole);
                itm.SubItems.Add(vEmail);
                itm.Tag = vLogin;
            }
            lblNbre.Text = lviewRech.Items.Count.ToString() + " utilisateurs";
        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            frmUtilisateurDetail frm = new frmUtilisateurDetail();
            frm.ShowDialog();
            rafraichirList();
        }

        private void btnModifier_Click(object sender, EventArgs e)
        {
            if (lviewRech.SelectedItems.Count > 0)
            {
                string vid = (string)lviewRech.SelectedItems[0].Tag;
                Utilisateur leUser = new Utilisateur(vid);
                frmUtilisateurDetail frm = new frmUtilisateurDetail(leUser, 'm');
                frm.ShowDialog();
                rafraichirList();
            }
        }

        private void btnConsulter_Click(object sender, EventArgs e)
        {
            if (lviewRech.SelectedItems.Count > 0)
            {
                string vid = (string)lviewRech.SelectedItems[0].Tag;
                Utilisateur leUser = new Utilisateur(vid);
                frmUtilisateurDetail frm = new frmUtilisateurDetail(leUser, 'c');
                frm.ShowDialog();
                rafraichirList();
            }
        }

        private void btnImprimer_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A FAIRE...", "IIT-L2");
        }

        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            if (lviewRech.SelectedItems.Count > 0)
            {
                string vid = (string)lviewRech.SelectedItems[0].Tag;
                Utilisateur leUser = new Utilisateur(vid);
                frmUtilisateurDetail frm = new frmUtilisateurDetail(leUser, 's');
                frm.ShowDialog();
                rafraichirList();
            }
        }

        private void btnActualiser_Click(object sender, EventArgs e)
        {
            rafraichirList();
        }

        private void txtFiltre_TextChanged(object sender, EventArgs e)
        {
            rafraichirList();
        }
    }
}
