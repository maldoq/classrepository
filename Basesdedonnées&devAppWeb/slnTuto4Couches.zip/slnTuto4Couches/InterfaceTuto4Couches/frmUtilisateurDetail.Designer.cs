﻿namespace InterfaceTuto4Couches
{
    partial class frmUtilisateurDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPassword = new TextBox();
            txtLogin = new TextBox();
            label2 = new Label();
            label1 = new Label();
            btnFermer = new Button();
            btnOk = new Button();
            txtEmail = new TextBox();
            txtNomComplet = new TextBox();
            label3 = new Label();
            label4 = new Label();
            cbRole = new ComboBox();
            label5 = new Label();
            SuspendLayout();
            // 
            // txtPassword
            // 
            txtPassword.CharacterCasing = CharacterCasing.Upper;
            txtPassword.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtPassword.ForeColor = Color.FromArgb(0, 0, 192);
            txtPassword.Location = new Point(162, 43);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '#';
            txtPassword.Size = new Size(211, 23);
            txtPassword.TabIndex = 21;
            // 
            // txtLogin
            // 
            txtLogin.CharacterCasing = CharacterCasing.Upper;
            txtLogin.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtLogin.ForeColor = Color.FromArgb(0, 0, 192);
            txtLogin.Location = new Point(162, 12);
            txtLogin.Name = "txtLogin";
            txtLogin.Size = new Size(211, 23);
            txtLogin.TabIndex = 20;
            // 
            // label2
            // 
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(30, 42);
            label2.Name = "label2";
            label2.Size = new Size(144, 23);
            label2.TabIndex = 19;
            label2.Text = "Mot de passe";
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(30, 11);
            label1.Name = "label1";
            label1.Size = new Size(144, 23);
            label1.TabIndex = 18;
            label1.Text = "Login name";
            // 
            // btnFermer
            // 
            btnFermer.BackColor = SystemColors.Control;
            btnFermer.FlatAppearance.BorderColor = Color.Blue;
            btnFermer.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 192);
            btnFermer.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 255);
            btnFermer.FlatStyle = FlatStyle.Flat;
            btnFermer.Location = new Point(301, 177);
            btnFermer.Name = "btnFermer";
            btnFermer.Size = new Size(70, 25);
            btnFermer.TabIndex = 23;
            btnFermer.Text = "&Fermer";
            btnFermer.UseVisualStyleBackColor = false;
            btnFermer.Click += btnFermer_Click;
            // 
            // btnOk
            // 
            btnOk.BackColor = SystemColors.Control;
            btnOk.FlatAppearance.BorderColor = Color.Blue;
            btnOk.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 192);
            btnOk.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 255);
            btnOk.FlatStyle = FlatStyle.Flat;
            btnOk.Location = new Point(220, 177);
            btnOk.Name = "btnOk";
            btnOk.Size = new Size(70, 25);
            btnOk.TabIndex = 22;
            btnOk.Text = "&Ok";
            btnOk.UseVisualStyleBackColor = false;
            btnOk.Click += btnOk_Click;
            // 
            // txtEmail
            // 
            txtEmail.CharacterCasing = CharacterCasing.Lower;
            txtEmail.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtEmail.ForeColor = Color.FromArgb(0, 0, 192);
            txtEmail.Location = new Point(162, 136);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(211, 23);
            txtEmail.TabIndex = 27;
            // 
            // txtNomComplet
            // 
            txtNomComplet.CharacterCasing = CharacterCasing.Upper;
            txtNomComplet.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtNomComplet.ForeColor = Color.FromArgb(0, 0, 192);
            txtNomComplet.Location = new Point(162, 74);
            txtNomComplet.Name = "txtNomComplet";
            txtNomComplet.Size = new Size(211, 23);
            txtNomComplet.TabIndex = 26;
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(30, 135);
            label3.Name = "label3";
            label3.Size = new Size(144, 23);
            label3.TabIndex = 25;
            label3.Text = "Email";
            // 
            // label4
            // 
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(30, 73);
            label4.Name = "label4";
            label4.Size = new Size(144, 23);
            label4.TabIndex = 24;
            label4.Text = "Nom et prénoms";
            // 
            // cbRole
            // 
            cbRole.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbRole.ForeColor = Color.FromArgb(0, 0, 192);
            cbRole.FormattingEnabled = true;
            cbRole.Items.AddRange(new object[] { "OPERATEUR", "MANAGER", "ADMINISTRATEUR" });
            cbRole.Location = new Point(162, 105);
            cbRole.Name = "cbRole";
            cbRole.Size = new Size(211, 23);
            cbRole.TabIndex = 29;
            // 
            // label5
            // 
            label5.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(30, 104);
            label5.Name = "label5";
            label5.Size = new Size(144, 23);
            label5.TabIndex = 28;
            label5.Text = "Rôle d'utilisateur";
            // 
            // frmUtilisateurDetail
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(224, 224, 224);
            ClientSize = new Size(401, 210);
            Controls.Add(cbRole);
            Controls.Add(label5);
            Controls.Add(txtEmail);
            Controls.Add(txtNomComplet);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(btnFermer);
            Controls.Add(btnOk);
            Controls.Add(txtPassword);
            Controls.Add(txtLogin);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmUtilisateurDetail";
            StartPosition = FormStartPosition.CenterParent;
            Text = "frmUtilisateurDetail";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPassword;
        private TextBox txtLogin;
        private Label label2;
        private Label label1;
        private Button btnFermer;
        private Button btnOk;
        private TextBox txtEmail;
        private TextBox txtNomComplet;
        private Label label3;
        private Label label4;
        private ComboBox cbRole;
        private Label label5;
    }
}