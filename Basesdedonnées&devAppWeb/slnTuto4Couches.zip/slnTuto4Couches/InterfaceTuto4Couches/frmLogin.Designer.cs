﻿namespace InterfaceTuto4Couches
{
    partial class frmLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnFermer = new Button();
            btnOk = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtLogin = new TextBox();
            txtPassword = new TextBox();
            cbRole = new ComboBox();
            pictureBox1 = new PictureBox();
            lblNomComplet = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnFermer
            // 
            btnFermer.BackColor = SystemColors.Control;
            btnFermer.FlatAppearance.BorderColor = Color.Blue;
            btnFermer.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 192);
            btnFermer.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 255);
            btnFermer.FlatStyle = FlatStyle.Flat;
            btnFermer.Location = new Point(399, 126);
            btnFermer.Name = "btnFermer";
            btnFermer.Size = new Size(70, 25);
            btnFermer.TabIndex = 12;
            btnFermer.Text = "&Fermer";
            btnFermer.UseVisualStyleBackColor = false;
            btnFermer.Click += btnFermer_Click;
            // 
            // btnOk
            // 
            btnOk.BackColor = SystemColors.Control;
            btnOk.FlatAppearance.BorderColor = Color.Blue;
            btnOk.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 192);
            btnOk.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 255);
            btnOk.FlatStyle = FlatStyle.Flat;
            btnOk.Location = new Point(318, 126);
            btnOk.Name = "btnOk";
            btnOk.Size = new Size(70, 25);
            btnOk.TabIndex = 11;
            btnOk.Text = "&Ok";
            btnOk.UseVisualStyleBackColor = false;
            btnOk.Click += btnOk_Click;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(152, 28);
            label1.Name = "label1";
            label1.Size = new Size(133, 23);
            label1.TabIndex = 13;
            label1.Text = "Login name";
            // 
            // label2
            // 
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(152, 60);
            label2.Name = "label2";
            label2.Size = new Size(133, 23);
            label2.TabIndex = 14;
            label2.Text = "Mot de passe";
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(152, 92);
            label3.Name = "label3";
            label3.Size = new Size(133, 23);
            label3.TabIndex = 15;
            label3.Text = "Rôle d'utilisateur";
            // 
            // txtLogin
            // 
            txtLogin.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtLogin.ForeColor = Color.FromArgb(0, 0, 192);
            txtLogin.Location = new Point(291, 29);
            txtLogin.Name = "txtLogin";
            txtLogin.Size = new Size(178, 23);
            txtLogin.TabIndex = 16;
            txtLogin.Validated += txtLogin_Validated;
            // 
            // txtPassword
            // 
            txtPassword.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtPassword.ForeColor = Color.FromArgb(0, 0, 192);
            txtPassword.Location = new Point(291, 61);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '#';
            txtPassword.Size = new Size(178, 23);
            txtPassword.TabIndex = 17;
            // 
            // cbRole
            // 
            cbRole.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            cbRole.ForeColor = Color.FromArgb(0, 0, 192);
            cbRole.FormattingEnabled = true;
            cbRole.Items.AddRange(new object[] { "OPERATEUR", "MANAGER", "ADMIN" });
            cbRole.Location = new Point(292, 93);
            cbRole.Name = "cbRole";
            cbRole.Size = new Size(177, 23);
            cbRole.TabIndex = 18;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.bebe1;
            pictureBox1.Location = new Point(0, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(144, 164);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 19;
            pictureBox1.TabStop = false;
            // 
            // lblNomComplet
            // 
            lblNomComplet.BackColor = Color.LightGoldenrodYellow;
            lblNomComplet.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblNomComplet.ForeColor = Color.Blue;
            lblNomComplet.Location = new Point(142, -1);
            lblNomComplet.Name = "lblNomComplet";
            lblNomComplet.Size = new Size(338, 23);
            lblNomComplet.TabIndex = 20;
            // 
            // frmLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(479, 163);
            Controls.Add(lblNomComplet);
            Controls.Add(pictureBox1);
            Controls.Add(cbRole);
            Controls.Add(txtPassword);
            Controls.Add(txtLogin);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnFermer);
            Controls.Add(btnOk);
            Name = "frmLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmLogin";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnFermer;
        private Button btnOk;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtLogin;
        private TextBox txtPassword;
        private ComboBox cbRole;
        private PictureBox pictureBox1;
        private Label lblNomComplet;
    }
}