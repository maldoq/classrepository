﻿namespace InterfaceTuto4Couches
{
    partial class FrmUtilisateurListe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFiltre = new TextBox();
            label1 = new Label();
            btnActualiser = new Button();
            btnFermer = new Button();
            btnSupprimer = new Button();
            btnModifier = new Button();
            btnAjouter = new Button();
            btnImprimer = new Button();
            btnConsulter = new Button();
            lviewRech = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            lblNbre = new Label();
            SuspendLayout();
            // 
            // txtFiltre
            // 
            txtFiltre.BackColor = SystemColors.Info;
            txtFiltre.Location = new Point(333, 12);
            txtFiltre.Name = "txtFiltre";
            txtFiltre.Size = new Size(161, 23);
            txtFiltre.TabIndex = 7;
            txtFiltre.TextChanged += txtFiltre_TextChanged;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(131, 15);
            label1.Name = "label1";
            label1.Size = new Size(194, 23);
            label1.TabIndex = 6;
            label1.Text = "Nom utilisateur commence par";
            // 
            // btnActualiser
            // 
            btnActualiser.Location = new Point(511, 12);
            btnActualiser.Name = "btnActualiser";
            btnActualiser.Size = new Size(70, 25);
            btnActualiser.TabIndex = 8;
            btnActualiser.Text = "Actualiser";
            btnActualiser.UseVisualStyleBackColor = true;
            btnActualiser.Click += btnActualiser_Click;
            // 
            // btnFermer
            // 
            btnFermer.BackColor = SystemColors.ButtonFace;
            btnFermer.FlatAppearance.BorderColor = Color.Blue;
            btnFermer.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 192);
            btnFermer.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 255);
            btnFermer.FlatStyle = FlatStyle.Flat;
            btnFermer.Location = new Point(605, 335);
            btnFermer.Name = "btnFermer";
            btnFermer.Size = new Size(75, 25);
            btnFermer.TabIndex = 10;
            btnFermer.Text = "&Fermer";
            btnFermer.UseVisualStyleBackColor = false;
            btnFermer.Click += btnFermer_Click;
            // 
            // btnSupprimer
            // 
            btnSupprimer.BackColor = SystemColors.ButtonFace;
            btnSupprimer.FlatAppearance.BorderColor = Color.Blue;
            btnSupprimer.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 192);
            btnSupprimer.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 255);
            btnSupprimer.FlatStyle = FlatStyle.Flat;
            btnSupprimer.Location = new Point(501, 335);
            btnSupprimer.Name = "btnSupprimer";
            btnSupprimer.Size = new Size(75, 25);
            btnSupprimer.TabIndex = 9;
            btnSupprimer.Text = "&Supprimer";
            btnSupprimer.UseVisualStyleBackColor = false;
            btnSupprimer.Click += btnSupprimer_Click;
            // 
            // btnModifier
            // 
            btnModifier.BackColor = SystemColors.ButtonFace;
            btnModifier.FlatAppearance.BorderColor = Color.Blue;
            btnModifier.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 192);
            btnModifier.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 255);
            btnModifier.FlatStyle = FlatStyle.Flat;
            btnModifier.Location = new Point(255, 335);
            btnModifier.Name = "btnModifier";
            btnModifier.Size = new Size(75, 25);
            btnModifier.TabIndex = 12;
            btnModifier.Text = "&Modifier";
            btnModifier.UseVisualStyleBackColor = false;
            btnModifier.Click += btnModifier_Click;
            // 
            // btnAjouter
            // 
            btnAjouter.BackColor = SystemColors.ButtonFace;
            btnAjouter.FlatAppearance.BorderColor = Color.Blue;
            btnAjouter.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 192);
            btnAjouter.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 255);
            btnAjouter.FlatStyle = FlatStyle.Flat;
            btnAjouter.Location = new Point(173, 335);
            btnAjouter.Name = "btnAjouter";
            btnAjouter.Size = new Size(75, 25);
            btnAjouter.TabIndex = 11;
            btnAjouter.Text = "&Ajouter";
            btnAjouter.UseVisualStyleBackColor = false;
            btnAjouter.Click += btnAjouter_Click;
            // 
            // btnImprimer
            // 
            btnImprimer.BackColor = SystemColors.ButtonFace;
            btnImprimer.FlatAppearance.BorderColor = Color.Blue;
            btnImprimer.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 192);
            btnImprimer.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 255);
            btnImprimer.FlatStyle = FlatStyle.Flat;
            btnImprimer.Location = new Point(419, 335);
            btnImprimer.Name = "btnImprimer";
            btnImprimer.Size = new Size(75, 25);
            btnImprimer.TabIndex = 14;
            btnImprimer.Text = "&Imprimer...";
            btnImprimer.UseVisualStyleBackColor = false;
            btnImprimer.Click += btnImprimer_Click;
            // 
            // btnConsulter
            // 
            btnConsulter.BackColor = SystemColors.ButtonFace;
            btnConsulter.FlatAppearance.BorderColor = Color.Blue;
            btnConsulter.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 192);
            btnConsulter.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 192, 255);
            btnConsulter.FlatStyle = FlatStyle.Flat;
            btnConsulter.Location = new Point(337, 335);
            btnConsulter.Name = "btnConsulter";
            btnConsulter.Size = new Size(75, 25);
            btnConsulter.TabIndex = 13;
            btnConsulter.Text = "&Consulter";
            btnConsulter.UseVisualStyleBackColor = false;
            btnConsulter.Click += btnConsulter_Click;
            // 
            // lviewRech
            // 
            lviewRech.BackColor = SystemColors.ScrollBar;
            lviewRech.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4 });
            lviewRech.FullRowSelect = true;
            lviewRech.GridLines = true;
            lviewRech.HoverSelection = true;
            lviewRech.Location = new Point(12, 47);
            lviewRech.Name = "lviewRech";
            lviewRech.Size = new Size(670, 280);
            lviewRech.TabIndex = 15;
            lviewRech.UseCompatibleStateImageBehavior = false;
            lviewRech.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Login Name";
            columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Nom et prénoms";
            columnHeader2.Width = 230;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Rôle";
            columnHeader3.Width = 120;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Email";
            columnHeader4.Width = 190;
            // 
            // lblNbre
            // 
            lblNbre.BackColor = SystemColors.Info;
            lblNbre.Location = new Point(12, 333);
            lblNbre.Name = "lblNbre";
            lblNbre.Size = new Size(155, 23);
            lblNbre.TabIndex = 16;
            lblNbre.Text = "TOTAL";
            // 
            // FrmUtilisateurListe
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSteelBlue;
            ClientSize = new Size(688, 367);
            Controls.Add(lblNbre);
            Controls.Add(lviewRech);
            Controls.Add(btnImprimer);
            Controls.Add(btnConsulter);
            Controls.Add(btnModifier);
            Controls.Add(btnAjouter);
            Controls.Add(btnFermer);
            Controls.Add(btnSupprimer);
            Controls.Add(btnActualiser);
            Controls.Add(txtFiltre);
            Controls.Add(label1);
            Name = "FrmUtilisateurListe";
            StartPosition = FormStartPosition.CenterParent;
            Text = "FrmUtilisateurListe";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFiltre;
        private Label label1;
        private Button btnActualiser;
        private Button btnFermer;
        private Button btnSupprimer;
        private Button btnModifier;
        private Button btnAjouter;
        private Button btnImprimer;
        private Button btnConsulter;
        private ListView lviewRech;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private Label lblNbre;
    }
}