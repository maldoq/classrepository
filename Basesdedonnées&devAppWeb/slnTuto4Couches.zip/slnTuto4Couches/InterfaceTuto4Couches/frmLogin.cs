using MetierTuto4Couches;
using Microsoft.VisualBasic.ApplicationServices;

namespace InterfaceTuto4Couches
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (Divers.ExisteUtilisateur(txtLogin.Text))
            {
                Utilisateur unUser = new Utilisateur(txtLogin.Text);
                if (unUser.UserLogin.ToUpper() == txtLogin.Text.ToUpper() && unUser.UserMotPass.ToUpper() == txtPassword.Text.ToUpper())
                {
                    //this.Visible = false;
                    txtLogin.Text = unUser.UserLogin;
                    lblNomComplet.Text = unUser.UserNomComplet;
                    cbRole.Text = unUser.UserRole;
                    FrmMenuPrincipal frm = new FrmMenuPrincipal();
                    frm.ShowDialog();
                    Application.Exit();
                }
                else
                {
                    MessageBox.Show("LOGIN ou MOT DE PASSE incorrectes", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else MessageBox.Show("Le LOGIN NAME est inexistant", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtLogin_Validated(object sender, EventArgs e)
        {
            if (Divers.ExisteUtilisateur(txtLogin.Text))
            {
                Utilisateur unUser = new Utilisateur(txtLogin.Text);
                lblNomComplet.Text = unUser.UserNomComplet;
                cbRole.SelectedIndex = cbRole.FindString(unUser.UserRole);
            }
            else
            {
                lblNomComplet.Text = "";
                txtPassword.Text = "";
                cbRole.SelectedIndex = -1;
            }

        }
    }
}