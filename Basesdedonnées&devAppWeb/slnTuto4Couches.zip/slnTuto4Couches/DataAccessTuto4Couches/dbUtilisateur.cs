﻿using CommonTuto4Couches;
using System.Data.SqlClient;
using System.Data;

namespace DataAccessTuto4Couches
{
    public class dbUtilisateur
    {
        //déclaration d'un attribut de classe de type SqlConnection pour la connection à la BD
        SqlConnection SqlConX = null;

      
        //Méthode SelectAll qui exécute la procédure stockée SPX_Utilisateur_SelectAll
        public DataTable SelectAll(string pUserNomComplet)
        {
            SqlConX = mUtilities.maDBConnection();
            SqlConX.Open();
            SqlCommand cmd = new SqlCommand("SPX_Utilisateur_SelectAll", SqlConX);
            cmd.CommandType = CommandType.StoredProcedure;
            //Ajout des paramètres
            SqlParameter prm;
            prm = new SqlParameter("@UserNomComplet", SqlDbType.VarChar, 50);
            prm.Value = pUserNomComplet;
            cmd.Parameters.Add(prm);

            //récupération des données
            DataTable dt= new DataTable(); 
            
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            //Remplissage du datatable
            da.Fill(dt);
            //Fermer la connexion
            CloseConnexion();
            return dt;
        }
        public string Insert(strUtilisateur pUser)
        {
            try
            {
                SqlConX = mUtilities.maDBConnection();
                SqlConX.Open();
                SqlCommand cmd = new SqlCommand("SPX_Utilisateur_Insert", SqlConX);
                cmd.CommandType = CommandType.StoredProcedure;

                //Ajout des paramètres
                SqlParameter prm;
                prm = new SqlParameter("@UserLogin", SqlDbType.VarChar, 10);
                prm.Value = pUser.UserLogin;
                cmd.Parameters.Add(prm);

                prm = new SqlParameter("@UserMotPass", SqlDbType.VarChar, 10);
                prm.Value = pUser.UserMotPass;
                cmd.Parameters.Add(prm);

                prm = new SqlParameter("@UserNomComplet", SqlDbType.VarChar, 50);
                prm.Value = pUser.UserNomComplet;
                cmd.Parameters.Add(prm);

                prm = new SqlParameter("@UserRole", SqlDbType.VarChar, 20);
                prm.Value = pUser.UserRole;
                cmd.Parameters.Add(prm);

                prm = new SqlParameter("@UserEmail", SqlDbType.VarChar, 50);
                prm.Value = pUser.UserEmail;
                cmd.Parameters.Add(prm);

                string res = (string)cmd.ExecuteScalar();
                CloseConnexion();
                return res;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string Update(strUtilisateur pUser)
        {
            try
            {
                SqlConX = mUtilities.maDBConnection();
                SqlConX.Open();
                SqlCommand cmd = new SqlCommand("SPX_Utilisateur_Update", SqlConX);
                cmd.CommandType = CommandType.StoredProcedure;

                //Ajout des paramètres
                SqlParameter prm;
                prm = new SqlParameter("@UserLogin", SqlDbType.VarChar, 10);
                prm.Value = pUser.UserLogin;
                cmd.Parameters.Add(prm);

                prm = new SqlParameter("@UserMotPass", SqlDbType.VarChar, 10);
                prm.Value = pUser.UserMotPass;
                cmd.Parameters.Add(prm);

                prm = new SqlParameter("@UserNomComplet", SqlDbType.VarChar, 50);
                prm.Value = pUser.UserNomComplet;
                cmd.Parameters.Add(prm);

                prm = new SqlParameter("@UserRole", SqlDbType.VarChar, 20);
                prm.Value = pUser.UserRole;
                cmd.Parameters.Add(prm);

                prm = new SqlParameter("@UserEmail", SqlDbType.VarChar, 50);
                prm.Value = pUser.UserEmail;
                cmd.Parameters.Add(prm);

                string res = (string)cmd.ExecuteScalar();
                CloseConnexion();
                return res;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public IDataReader GetObject(string pLogin)
        {
            IDataReader dr = null;

            //Définition de la chaine de connexion
            SqlConX = mUtilities.maDBConnection();
            SqlConX.Open();
            //Commande
            SqlCommand cmd = new SqlCommand("SPX_Utilisateur_Get", SqlConX);
            cmd.CommandType = CommandType.StoredProcedure;
            //Paramètres
            SqlParameter prm;
            prm = new SqlParameter("@UserLogin", SqlDbType.VarChar, 10);
            prm.Value = pLogin;
            cmd.Parameters.Add(prm);

            dr = cmd.ExecuteReader();
            return dr;
        }
        public string Supprimer(string pLogin)
        {
            try
            {
                //Définition de la chaine de connexion
                SqlConX = mUtilities.maDBConnection();
                SqlConX.Open();
                SqlCommand cmd = new SqlCommand("SPX_Utilisateur_Delete", SqlConX);
                cmd.CommandType = CommandType.StoredProcedure;
                //Ajout des paramètres
                SqlParameter prm;
                prm = new SqlParameter("@UserLogin", SqlDbType.VarChar, 10);
                prm.Value = pLogin;
                cmd.Parameters.Add(prm);

                string res = (string)cmd.ExecuteScalar();
                SqlConX.Close();
                return res;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //Méthode de fermeture de la connexion à la BD
        public void CloseConnexion()
        {
            if ((SqlConX != null) && SqlConX.State == ConnectionState.Open)
            {
                SqlConX.Close();
            }
        }

    }

}
